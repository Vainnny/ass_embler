#ifndef REGION_DETECTOR_H
#define REGION_DETECTOR_H

#include "bmp_handler.h"

int* find_regions(BMPImage* image, int* region_count);

#endif // REGION_DETECTOR_H